package br.uefs.ecomp.siscareta.util;

public interface Iterador {
	
	public boolean temProximo();

	public Object obterProximo();

}
