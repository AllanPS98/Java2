package br.uefs.ecomp.siscareta.controller;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import br.uefs.ecomp.siscareta.util.Iterador;
import junit.framework.TestCase;

public class ControllerTest extends TestCase{

	private Controller controller;
	
	@Before
	public void setUp(){
		controller = new Controller();
	}
	
	@Test
	public void testInsereBlocoComSucesso(){
		Bloco bloco = new Bloco("Bafo de Baco");
		controller.salvarBloco(bloco);
		
		Iterador<Bloco> itr  = controller.listarBlocos();
		Bloco blocoRetorno = null;
		while(itr.temProximo()){
			blocoRetorno = itr.obterProximo();
			break;
		}		
		assertEquals("Bafo de Baco", blocoRetorno.getNome());
		assertEquals(1, blocoRetorno.getId());
	}
	
	@Test
	public void testInsereAtracaoComSucesso(){
		Atracao atracao = new Atracao("Ivete Sangalo");
		controller.salvarAtracao(atracao);
		
		Iterador<Atracao> itr  = controller.listarAtracoes();
		Atracao atracaoRetorno = null;
		while(itr.temProximo()){
			atracaoRetorno = itr.obterProximo();
			break;
		}		
		assertEquals("Ivete Sangalo", atracaoRetorno.getNome());
		assertEquals(1, atracaoRetorno.getId());
	}
	
	@Test
	public void testAdicionaDataNaoPertencenteAoIntervaloDeDatasDaMicaretaAoBloco(){
		Bloco bloco = new Bloco("Bafo de Baco");
		controller.salvarBloco(bloco);
		LocalDate dataBlocoNaMicareta = LocalDate.of(2017, Month.MAY, 22);
		boolean inseriuData = bloco.adicionarData(dataBlocoNaMicareta);
		assertEquals(1, inseriuData);
	}
	
	@Test
	public void testAdicionaDataPertencenteAoIntervaloDeDatasDaMicaretaAoBloco(){
		Bloco bloco = new Bloco("Bafo de Baco");
		controller.salvarBloco(bloco);
		LocalDate dataBlocoNaMicareta = LocalDate.of(2017, Month.MAY, 20);
		int inseriuData = bloco.adicionarData(dataBlocoNaMicareta);
		assertEquals(0, inseriuData);
	}
	
	@Test
	public void testAssociaAtracaoAoBlocoComSucesso(){
		Bloco bloco = new Bloco("Bafo de Baco");
		controller.salvarBloco(bloco);
		LocalDate dataBlocoNaMicareta = LocalDate.of(2017, Month.MAY, 20);
		bloco.adicionarData(dataBlocoNaMicareta);
		
		Atracao atracao = new Atracao("Ivete Sangalo");
		controller.salvarAtracao(atracao);
		
		int cadastrouAtracaoNoBloco = controller.cadastrarAtracaoNoBloco(atracao, bloco, dataBlocoNaMicareta, 5000);
		
		assertEquals(0, cadastrouAtracaoNoBloco);
	}
	
	@Test
	public void testAssociaAtracaoAoBlocoEmDataErrada(){
		Bloco bloco = new Bloco("Bafo de Baco");
		controller.salvarBloco(bloco);
		LocalDate dataBlocoNaMicareta = LocalDate.of(2017, Month.MAY, 20);
		bloco.adicionarData(dataBlocoNaMicareta);
		
		Atracao atracao = new Atracao("Ivete Sangalo");
		controller.salvarAtracao(atracao);
		LocalDate dataAtracaoNoBloco = LocalDate.of(2017, Month.MAY, 19);
		int cadastrouAtracaoNoBloco = controller.cadastrarAtracaoNoBloco(atracao, bloco, dataAtracaoNoBloco, 5000);
		
		assertEquals(1, cadastrouAtracaoNoBloco);
	}
	
	@Test
	public void testAssociaUmaAtracaoADoisBlocosNumaMesmaData(){
		Bloco bloco = new Bloco("Bafo de Baco");
		controller.salvarBloco(bloco);
		LocalDate dataBlocoNaMicareta = LocalDate.of(2017, Month.MAY, 20);
		bloco.adicionarData(dataBlocoNaMicareta);
		
		Bloco bloco2 = new Bloco("Vumbora");
		controller.salvarBloco(bloco2);
		bloco2.adicionarData(dataBlocoNaMicareta);
		
		Atracao atracao = new Atracao("Ivete Sangalo");
		controller.salvarAtracao(atracao);
		
		int cadastrouAtracaoNoBloco = controller.cadastrarAtracaoNoBloco(atracao, bloco, dataBlocoNaMicareta, 5000);
		assertEquals(true, cadastrouAtracaoNoBloco);
		
		cadastrouAtracaoNoBloco = controller.cadastrarAtracaoNoBloco(atracao, bloco2, dataBlocoNaMicareta, 5000);
		assertEquals(2, cadastrouAtracaoNoBloco);
	}
	
}
